<div class="post-result">

	<?php if(has_post_thumbnail()): ?>
	
	<div class="post-image">
		<a class="image" href="<?php the_permalink(); ?>" style="background: url(<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) );?>) center center no-repeat; background-size: cover;"></a>
	</div>
	
	<div class="post-text">
	
	<?php else: ?>
	
	<div class="post-text full-width">
	
	<?php endif; ?>
	
		<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<time datetime="<?php the_time( 'Y-m-d' ); ?>" pubdate><?php the_date(); ?></time>
		<?php the_excerpt(); ?>

		<a class="readmore btn-outline" href="<?php the_permalink(); ?>">Read more</a>
	</div>
</div>