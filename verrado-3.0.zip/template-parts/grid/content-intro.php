<section class="fullwidth intro">
	<div class="wrap">
		<div class="sm-12">
			<article class="feature">
					
				<?php the_content(); ?>
				
			</article>
		</div>
	</div>
</section>