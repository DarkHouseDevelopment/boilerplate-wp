<?php
	global $post, $post_parent;
?>
<section class="showcase-content">
	<div class="wrap">
		<div class="sm-12">
			<article>
				<h1 class='page-title'><?php the_title(); ?></h1>
			</article>
		</div>
	</div>
</section>

<section class="showcase-content">
	<div class="wrap">
		<div class="sm-12">
			<article>
				<div class="featured-img">
					<?php $featured_img = get_field( 'featured_image' ); ?>
					<img src="<?php echo $featured_img['url']; ?>" alt="" />
				</div>
				
				<div class="section-content">
					<h2><span><?php echo get_the_title( $post_parent ); ?></span> - <?php the_field( 'model_name' ); ?></h2>
					<?php the_field( 'home_description' ); ?>
					
					<h3><?php echo get_field( 'previous_price' ) ? 'WAS: $'.number_format(get_field( 'previous_price' )).' - ' : ''; ?><span>NOW: $<?php echo number_format(get_field( 'current_price' )); ?></span></h3>
					
					<?php if(have_rows( 'features_list' )): ?>
						<ul class="features-list">
							<?php while(have_rows( 'features_list' )): the_row(); ?>
								<li><?php the_sub_field( 'feature' ); ?></li>
							<?php endwhile; ?>
						</ul>
					<?php endif; ?>
				</div>
			</article>
		</div>
	</div>
</section>

<section class="showcase-content">
	<div class="wrap">
		<div class="sm-12">
			<article>
				<div class="section-content">
					<?php the_field( 'additional_details' ); ?>
				</div>
				
				<div class="collage-content">
					<div class="collage">
						<?php 
							$collage_images = get_field( 'image_collage' );
							
							foreach($collage_images as $collage_img):
								echo "<div class='collage-img'><img src='{$collage_img['url']}' alt='' /></div>";
							endforeach;
						?>
					</div>
				</div>
			</article>
		</div>
	</div>
</section>
