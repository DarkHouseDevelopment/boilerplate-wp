<?php
	echo '<div class="entry-content">';
	echo do_shortcode( '[wpmem_form login texturize=false]' );
	echo '</div>';