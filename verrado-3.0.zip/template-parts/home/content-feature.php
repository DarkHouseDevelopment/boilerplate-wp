<section class="fullwidth">
	<div class="wrap">
		<div class="sm-12">
			<article class="feature">
				<header>
					<h1 class="script"><?php the_sub_field("section_title"); ?></h1>
				</header>
					
				<?php the_sub_field("section_content"); ?>
				
			</article>
		</div>
	</div>
</section>