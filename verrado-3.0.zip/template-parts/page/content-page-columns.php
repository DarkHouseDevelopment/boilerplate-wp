<section class="default-content columns">
	<div class="wrap">
		<div class="sm-12">
			<article class="columns">
				<?php the_sub_field("page_content"); ?>
			</article>
		</div>
	</div>
</section>