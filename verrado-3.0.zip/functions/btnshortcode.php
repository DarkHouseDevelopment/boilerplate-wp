<?php
	// Add Shortcode
	function btn_shortcode( $atts , $content = null ) {
	
		// Attributes
		$atts = shortcode_atts(
			array(
				'link' => 'http://www.verrado.com',
				'target' => '_self',
			),
			$atts,
			'btn'
		);
		if (strpos($atts["link"], "http") !== 0 && substr($atts["link"], 0, 1) != "/") {
		    $atts["link"] = "http://".$atts["link"];
		}
	
		return "<p><a class='btn btn-darkteal' href='".$atts["link"]."' target='".$atts["target"]."'>".$content."</a></p>";
	
	}
	add_shortcode( 'btn', 'btn_shortcode' );
	
	function add_button() {
		if(current_user_can('edit_posts') &&  current_user_can('edit_pages')){
			add_filter('mce_external_plugins', 'add_plugin');
			add_filter('mce_buttons', 'register_button');
		}
	}
	add_action('init', 'add_button');
	
	function register_button($buttons) {
		array_push($buttons, "btn");
		return $buttons;
	}
	function add_plugin($plugin_array) {
		$plugin_array['btn'] = get_bloginfo('template_url').'/assets/js/btn_shortcode.js';
		return $plugin_array;
	}