<?php get_header(); ?>

	<div class="wrap">

		<section class="content" role="main">
			
			<h2>Oops, page not found :(</h2>
			<a href="<?php bloginfo('url'); ?>" class="btn">Back to homepage</a>
		
		</section>
	
	</div>

<?php get_footer(); ?>