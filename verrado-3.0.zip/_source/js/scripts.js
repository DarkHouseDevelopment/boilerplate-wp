/************************************************************************/
/* SCRIPTS
/************************************************************************/

$(document).ready(function() {
	
	mobileNavSlideIn();
	mobileHeaderSlideUp();
	mobileHomeSearch();
	hoverSubnav();
	slidersInit();
	galleryOverlayInit();
	gridInit();
	floatingLabels();
	minMaxPrice();
	browse_builders();
	iCheckInit();
	floorplans();
	sendInfoForm();
	formSubmits();
	newsMonthlyArchiveNav();
	
});

$(window).load(function(){ 
	gridInit();
});